# SFitness Website 🏋️‍♀️⚡

Este é o site da marca **SFitness**, feito para ser publicado no **GitHub Pages**.

## 🚀 Publicar no GitHub Pages

1. Crie um repositório no GitHub (ex: `sfitness-site`).
2. Faça o upload destes arquivos (`index.html`, `styles.css`, `script.js` e a pasta `assets/` se quiser incluir imagens).
3. Vá em **Settings > Pages**.
4. Em **Source**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Clique em **Save**.

Após alguns minutos, seu site estará no ar em:

```
https://SEUUSUARIO.github.io/sfitness-site/
```

## 📂 Estrutura dos arquivos
- `index.html` → Página principal
- `styles.css` → Estilos (cores, layout, fontes)
- `script.js` → Interações
- `assets/` → Coloque aqui imagens e logos
- `README.md` → Este guia
